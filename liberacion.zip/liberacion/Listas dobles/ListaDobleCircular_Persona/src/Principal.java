
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LD_CircularPer A =  new LD_CircularPer();
		A.leer2(5);
		A.mostrar();
		System.out.println("---------------------------");
		A.eliFinal();
		A.eliPrimero();
		A.mostrar();
		System.out.println("---------------------------");
		A.eliPrimero();
		A.eliPrimero();
		A.mostrar();
		System.out.println("---------------------------");
		A.eliPrimero();
		A.eliPrimero();
		A.mostrar();
		System.out.println(A.nroNodos());
		
	}

}
