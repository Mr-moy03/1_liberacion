import java.util.Scanner;

//Lic Aruquipa Marcelo
public class LD_CircularPer extends ListaDoblePer{
	public LD_CircularPer() {
		super();
	}
	boolean esVacia() {
		if(this.P == null)
			return true;
		return false;
	}
	int nroNodos() {
		int c = 0;
		NodoPer R = P;
		if(!esVacia()) {
			while(R.getSig() != P) {
				c++;
				R = R.getSig();
			}
			c++;
		}
		return c;
	}
	void adiPrimero(String nom, int edad){
		NodoPer nuevo = new NodoPer();
		nuevo.setNom(nom);
		nuevo.setEdad(edad);

		if(esVacia()) {
			P = nuevo;
			P.setSig(P);
			P.setAnt(P);
		}
		else {
			NodoPer R = P.getAnt();
			nuevo.setSig(P);
			P.setAnt(nuevo);
			P = nuevo;
			P.setAnt(R);
			R.setSig(P);
		}
	}
	void mostrar() {
		NodoPer R = P;
		if(!esVacia()) {
			while(R.getSig() != P) {
				System.out.println(R.getNom() + " " + R.getEdad());
				R = R.getSig();
			}
			System.out.println(R.getNom() + " " + R.getEdad());
		}
		else
			System.out.println("Lista Vacia");
	}

	void adiFinal(String nom, int edad) {
		NodoPer nuevo = new NodoPer();
		nuevo.setNom(nom);
		nuevo.setEdad(edad);

		if(esVacia()) {
			P = nuevo;
			P.setSig(P);
			P.setAnt(P);
		}
		else {
			NodoPer R = P.getAnt();
			R.setSig(nuevo);
			nuevo.setAnt(R);
			nuevo.setSig(P);
			P.setAnt(nuevo);
		}
	}

	NodoPer eliPrimero() {
		NodoPer x = new NodoPer();
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;
				P = null;
			}else {
				x = P;
				NodoPer R = P.getAnt();
				P = P.getSig();
				P.setAnt(R);
				R.setSig(P);
			}
			x.setSig(null);
			x.setAnt(null);
		}
		return x;
	}

	NodoPer eliFinal() {
		NodoPer x = new NodoPer();
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;
				P = null;
			}else {
				x = P.getAnt();
				NodoPer R = x.getAnt();
				R.setSig(P);
				P.setAnt(R);
			}
			x.setSig(null);
			x.setAnt(null);
		}
		return x;
	}

	void leer1(int n) {
		Scanner lee =  new Scanner(System.in);
		for (int i = 1; i <= n; i++) {
			System.out.println("nom - edad");
			String nom = lee.next();
			int edad = lee.nextInt();
			adiPrimero(nom, edad);
		}
	}

	void leer2(int n) {
		Scanner lee =  new Scanner(System.in);
		for (int i = 1; i <= n; i++) {
			System.out.println("nom - edad");
			String nom = lee.next();
			int edad = lee.nextInt();
			adiFinal(nom, edad);
		}
	}
}
