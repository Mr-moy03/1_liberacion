//Lic Aruquipa Marcelo
public class ListaDoblePer {
	protected NodoPer P;
	
	ListaDoblePer(){
		this.P = null;
	}

	public NodoPer getP() {
		return P;
	}

	public void setP(NodoPer p) {
		P = p;
	}
	
}
