//AB_Normal.java
import java.util.Scanner;
public class AB_Normal extends ArbolBinario {
	public void crear(Nodo R) {
		Scanner lee = new Scanner(System.in);
		if(R != null) {
			Persona x = new Persona();
			x.leer();
			R.setPer(x);
			System.out.println("tendra izq? s/n");
			String resp = lee.next();
			if(resp.equals("s")) {
				Nodo nuevo = new Nodo();
				R.setIzq(nuevo);
				crear(R.getIzq());
			}
			System.out.println("tendra der? s/n");
			resp = lee.next();
			if(resp.equals("s")) {
				Nodo nuevo = new Nodo();
				R.setDer(nuevo);
				crear(R.getDer());
			}
		}
	}
	public void preorden(Nodo R) {
		if(R != null) {
			R.getPer().mostrar();
			preorden(R.getIzq());
			preorden(R.getDer());
		}
	}
}
