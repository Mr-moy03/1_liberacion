//Principal.java
public class Principal {

	public static void main(String[] args) {
		AB_Normal z = new AB_Normal();
		Nodo r = new Nodo();
		z.setRaiz(r);
		z.crear(z.getRaiz());
		z.preorden(z.getRaiz());
	}

}
