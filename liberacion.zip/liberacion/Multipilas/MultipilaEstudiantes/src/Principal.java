
public class Principal {

	public static void main(String[] args) {
		
		PilaPasajero pila1 = new PilaPasajero();
		PilaPasajero pila2 = new PilaPasajero();
		PilaPasajero pila3 = new PilaPasajero();
		PilaPasajero pila4 = new PilaPasajero();
		PilaPasajero pila5 = new PilaPasajero();
		
		Pasajero p1 = new Pasajero("Lucía Martínez", 25, "Adulto");
		Pasajero p2 = new Pasajero("Carlos Gómez", 12, "Niño");
		Pasajero p3 = new Pasajero("Ana Torres", 65, "Adulto Mayor");
		Pasajero p4 = new Pasajero("Pedro Rivera", 35, "Adulto");
		Pasajero p5 = new Pasajero("Sofía Ramírez", 19, "Estudiante");
		Pasajero p6 = new Pasajero("Miguel López", 45, "Adulto");
		Pasajero p7 = new Pasajero("Isabel Hernández", 8, "Niño");
		Pasajero p8 = new Pasajero("Jorge Salas", 70, "Adulto Mayor");
		Pasajero p9 = new Pasajero("Camila Núñez", 16, "Estudiante");
		Pasajero p10 = new Pasajero("Tomás Castillo", 50, "Adulto");
		
		pila1.push(p1);
		pila1.push(p2);
		pila1.push(p3);
		pila1.push(p4);
		
		
		pila2.push(p5);
		pila2.push(p6);
		pila2.push(p7);
		
		
		pila3.push(p8);
		pila3.push(p9);
		pila3.push(p1);
		
		
		pila4.push(p10);
		pila4.push(p2);
		pila4.push(p5);
		pila4.push(p7);
		
		pila5.push(p2);
		pila5.push(p3);
		pila5.push(p4);
		pila5.push(p7);
		
		//pila1.mostrar();
		
		Bus bus1 = new Bus("ABC123", "Rojo", pila1, "Carlos Pérez", "Ruta 1");
		Bus bus2 = new Bus("DEF456", "Azul", pila2, "María López", "Ruta 2");
		Bus bus3 = new Bus("GHI789", "Verde", pila3, "Juan García", "Ruta 3");
		Bus bus4 = new Bus("JKL012", "Amarillo", pila4, "Ana Torres", "Ruta 4");
		Bus bus5 = new Bus("MNO345", "Blanco", pila5, "Luis Rodríguez", "Ruta 5");
		
		/*
		bus1.mostrar();
		bus2.mostrar();
		bus3.mostrar();
		bus4.mostrar();
		bus5.mostrar();
		*/
		
		PilaBus pila_bus = new PilaBus();
		pila_bus.push(bus1);
		pila_bus.push(bus3);
		pila_bus.push(bus4);
		pila_bus.push(bus2);
		pila_bus.push(bus5);
		
		//pila_bus.mostrar();
		
		
		Mp_PilaBus mPilaBus = new Mp_PilaBus(5);
		
		mPilaBus.adicionar(0, bus1);
		mPilaBus.adicionar(1, bus2);
		mPilaBus.adicionar(2, bus3);
		mPilaBus.adicionar(3, bus4);
		mPilaBus.adicionar(4, bus5);

		mPilaBus.mostrar();
	
		
		
		
		
	
	}
}
