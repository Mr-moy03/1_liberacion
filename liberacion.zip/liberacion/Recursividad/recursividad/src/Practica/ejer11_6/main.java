package Practica.ejer11_6;

// Asegúrate de tener tus imports correctos según tu estructura de carpetas
// import Practica.ejer11_3.PilaChar;
// import Practica.ejer11_4.PilaEnemigo;

public class main {
    public static void main(String[] args) {
        // 1. Creación de datos de prueba
        // Agregamos un libro con título palíndromo ("Neuquen") para probar que funciona
        Libro e1 = new Libro("Undertale", "Toby Fox", "Videojuego", 95);
        Libro e2 = new Libro("Neuquen", "Mapuche", "Geografia", 75); // "neuquen" es palíndromo
        Libro e3 = new Libro("Harry Potter", "J.K. Rowling", "Fantasia", 300);
        Libro e4 = new Libro("El Hobbit", "Tolkien", "Fantasía", 250); // Con tilde

        LS_NormalLibro lista = new LS_NormalLibro();
        lista.adiFinal(e1);
        lista.adiFinal(e2);
        lista.adiFinal(e3);
        lista.adiFinal(e4);

        // 2. PRUEBA DEL PALÍNDROMO (Inciso A)
        // ERROR COMÚN CORREGIDO: No puedes pasar 'lista' (objeto LS_NormalLibro).
        // Debes pasar 'lista.getP()' porque la función recursiva espera un 'NodoLibro'.
        System.out.println("--- Probando Palíndromo ---");
        boolean existe = existeLibroPalindromo(lista.getP());
        if(existe) {
            System.out.println("Resultado: SI existe un libro con título palíndromo.");
        } else {
            System.out.println("Resultado: NO existe ningún libro palíndromo.");
        }

        // 3. PRUEBA DEL CONTEO DE FANTASÍA (Inciso B)
        System.out.println("\n--- Probando Conteo Fantasía ---");
        int cantidad = contarFantasia(lista.getP());
        System.out.println("Cantidad de libros de Fantasía: " + cantidad);
    }

    // -------------------------------------------------------------------------
    // INCISO A: Verificar Palíndromo
    // -------------------------------------------------------------------------

    // CAMBIO IMPORTANTE: Debe ser 'static' para llamarse desde el main.
    public static boolean existeLibroPalindromo(NodoLibro R) {
        // Caso Base: Fin de la lista
        if (R == null) {
            return false;
        } else {
            // Proceso: Verificamos título. Usamos getLib() según tu estructura.
            if (esPalindromo(R.getLib().getTitulo())) {
                return true; // Corta la recursión apenas encuentra uno
            }
            // Llamada Recursiva
            return existeLibroPalindromo(R.getSig());
        }
    }

    // Función auxiliar (No requiere cambios, solo asegurarnos que sea static)
    public static boolean esPalindromo(String texto) {
        if (texto == null) return false;
        String limpio = texto.replace(" ", "").toLowerCase();
        return verificarPalindromoRec(limpio, 0, limpio.length() - 1);
    }

    // Recursividad de caracteres
    public static boolean verificarPalindromoRec(String s, int inicio, int fin) {
        if (inicio >= fin) return true;
        if (s.charAt(inicio) != s.charAt(fin)) return false;
        return verificarPalindromoRec(s, inicio + 1, fin - 1);
    }

    // -------------------------------------------------------------------------
    // INCISO B: Contar Fantasía
    // -------------------------------------------------------------------------

    // CAMBIO IMPORTANTE: Agregamos lógica para tildes y mayúsculas
    public static int contarFantasia(NodoLibro R) {
        if (R == null) {
            return 0; // Caso Base
        } else {
            // Llamada Recursiva primero (se puede hacer antes o después)
            int cont = contarFantasia(R.getSig());

            // Proceso: Obtenemos el género
            String genero = R.getLib().getGenero();

            // Verificamos ignorando mayúsculas y considerando "Fantasía" con tilde
            if (genero.equalsIgnoreCase("fantasía") || genero.equalsIgnoreCase("fantasia")) {
                cont++;
            }
            return cont;
        }
    }
}