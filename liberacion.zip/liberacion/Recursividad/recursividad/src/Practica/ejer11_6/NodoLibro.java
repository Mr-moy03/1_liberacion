package Practica.ejer11_6;

public class NodoLibro {
	private Libro lib;
	private NodoLibro sig;
	
	public NodoLibro() {  //constructor
		sig = null;
	}

	public Libro getLib() {
		return lib;
	}

	public void setLib(Libro lib) {
		this.lib = lib;
	}

	public NodoLibro getSig() {
		return sig;
	}

	public void setSig(NodoLibro sig) {
		this.sig = sig;
	}
	
}
