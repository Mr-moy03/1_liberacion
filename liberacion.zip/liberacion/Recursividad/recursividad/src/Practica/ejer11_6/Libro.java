package Practica.ejer11_6;

public class Libro {
    //[titulo, autor, genero, nroPaginas]
    private String titulo;
    private String autor;
    private String genero;
    private int nroPaginas;

    public Libro(String titulo,String autor,String genero,int nroPaginas){
        this.titulo = titulo;
        this.autor = autor;
        this.genero = genero;
        this.nroPaginas = nroPaginas;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getNroPaginas() {
        return nroPaginas;
    }

    public void setNroPaginas(int nroPaginas) {
        this.nroPaginas = nroPaginas;
    }

    @Override
    public String toString(){
        return String.format("[titulo: %s, autor: %s , genero: %s, nroPaginas: %d]",getTitulo(),getAutor(),getTitulo(),getNroPaginas());
    }
    public void mostrar(){
        System.out.println(toString());
    }
}
