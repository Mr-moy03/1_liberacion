package Practica.ejer11_6;

public class LS_NormalLibro extends ListaSimpleLibro {

	public LS_NormalLibro() {
		super();
	}

	public boolean esVacia() {
		if(P == null)
			return true;
		return false;
	}

	public void adiPrincipio(Libro z) {
		NodoLibro nuevo = new NodoLibro(); //composicion
		nuevo.setLib(z);
		nuevo.setSig(P); //el siguiente del nodo nuevo apunta a nodo raiz
		P = nuevo;      //P apunta a nuevo
	}
	
	public void adiFinal(Libro z) {
		NodoLibro nuevo = new NodoLibro();
		nuevo.setLib(z);
		
		if(esVacia())
			P = nuevo;   //p apunta a nuevo
		else {
			NodoLibro R = P;
			while( R.getSig() != null ){
			     R = R.getSig();
			}
			R.setSig(nuevo);
		}
	}
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        NodoLibro R = P;
        while(R != null) {
            s.append(R.getLib());
            //R.getEmpl().mostrar();
            R = R.getSig();
        }
        return s.toString();
    }

    public void mostrar() {
        System.out.println(toString());
    }

	public int nroNodos() {
		NodoLibro R = P;
		int c = 0;
		if(this.esVacia())
			return 0;
		else {
			while(R != null) {
				c++;
				R = R.getSig();
			}
		}
		return c;
	}
	
	public NodoLibro eliPrincipio() {
		NodoLibro x = null;
		if(!esVacia()) {
			x = P ;     // x apunta a la raiz P
			P = P.getSig();
			x.setSig(null);
		}
		return x;
	}
	
	public NodoLibro eliFinal() {
		NodoLibro x = null;
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;      //x apunta a la raiz P
				P = null;
			}else {
				NodoLibro R = P;
				NodoLibro S = P;
				while(R.getSig() != null) {
					S = R;         //S apunta a R
					R = R.getSig(); //R apunta al siguiente de R
				}
				x = R;
				S.setSig(null);
			}
		}
		return x;
	}
	/*
	public void leer1(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiPrincipio(z);
		}
	}
	
	public void leer2(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiFinal(z);
		}
	}*/
}
