package Practica.ejer11_6;

public class ListaSimpleLibro {
	protected NodoLibro P;
	public ListaSimpleLibro() {
		P = null;
	}
	public NodoLibro getP() {
		return P;
	}
	public void setP(NodoLibro p) {
		P = p;
	}
	
}
