package Practica.ejer11_5;

public class ColaCircularEnteros {
    protected int MAX = 50;
    protected int[] v = new int[MAX];
    protected int fr;
    protected int fi;

    public ColaCircularEnteros() {
        this.fr = 0;
        this.fi = 0;
    }

    public int nroElem() {
        return (fi - fr + MAX) % MAX;
    }
    public boolean esVacia() {
        if(nroElem() == 0)
            return true;
        return false;

    }
    public boolean esLlena() {
        if(nroElem() == MAX-1)
            return true;
        return false;
    }
    public void push(int elem) {
        if(!esLlena()) {
            fi = (fi + 1) % MAX;
            v[fi] = elem;
        }else
            System.out.println("cola circular llena!!!");
    }
    public int pop() {
        int elem;
        if(!esVacia()) {
            fr = (fr + 1) % MAX;
            elem = v[fr];
            return elem;
        }else {
            System.out.println("Cola circular vacia!!");
            return 0;
        }
    }

    public void vaciar(ColaCircularEnteros z) {
        while(!z.esVacia()) {
            push(z.pop());
        }
    }

    public void mostrar() {
        ColaCircularEnteros aux = new ColaCircularEnteros();
        while(!esVacia()) {
            int elem = pop();
            System.out.println(elem);
            //elem.mostrar();
            aux.push(elem);
        }
        vaciar(aux);
    }
}


