package Practica.ejer11_5;

import Practica.ejer11_4.PilaEnemigo;

public class main {
    public static void main(String[] args) {
        ColaCircularEnteros cc = new ColaCircularEnteros();
        cc.push(3);
        cc.push(5);
        cc.push(7);
        cc.push(2);


        System.out.println(sumarCola(cc, cc.nroElem()));
    }

    // Llamada: sumarCola(cola, cola.nroElem());
    public static int sumarCola(ColaCircularEnteros C, int n) {
        if (n == 0) {
            return 0; // Caso Base: Se procesaron todos los elementos
        } else {
            int x = C.pop();
            int suma = x + sumarCola(C, n - 1); // Recursión reduciendo n
            C.push(x); // Restaurar Cola (rotación)
            return suma;
        }
    }
}
