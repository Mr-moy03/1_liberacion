package Practica.ejer11_3;

public class main {
    public static void main(String[] args) {
        PilaChar pila_1 = new PilaChar();
        pila_1.adi('a');
        pila_1.adi('b');
        pila_1.adi('c');
        pila_1.adi('d');

        PilaChar pila_2 = new PilaChar();
        pila_2.adi('a');
        pila_2.adi('e');
        pila_2.adi('i');
        pila_2.adi('o');
        pila_2.adi('u');

        esPilaPalindromo(pila_1);

    }
    public static boolean esPilaPalindromo(PilaChar A) {
        String palabra = formarPalabra(A);
        String invertida = "";
        for (int i = palabra.length() - 1; i >= 0; i--) {
            invertida += palabra.charAt(i);
        }
        return palabra.equals(invertida);
    }

    // Método auxiliar recursivo para extraer el String sin perder la pila
    public static String formarPalabra(PilaChar A) {
        if (A.esVacia()) {
            return ""; // Caso Base
        } else {
            char c = A.eli();
            String resto = formarPalabra(A); // Recursión
            A.adi(c); // Restaurar pila
            return c + resto; // Concatenar carácter
        }
    }
}
