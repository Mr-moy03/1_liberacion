package Practica.ejer11_1;

public class main {
    public static void main(String[] args){
        System.out.println("Fibopnacci");
        int f = fibonacci(2);
        System.out.println(f);

        mostrar(7);
    }

    public static int fibonacci(int n) {
        // Caso Base
        if (n == 1) return 0;
        else {
            if (n == 2) return 1;
            // Llamada Recursiva
            else return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void mostrar(int n) {
        // Caso recursivo
        if (n != 0) {
            mostrar(n - 1);
            System.out.print(n + ",");
        }
    }
}


