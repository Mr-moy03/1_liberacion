package Practica.ejer11_4;

public class PilaEnemigo {
    protected int max = 50;
    protected Enemigo v[] = new Enemigo[max];
	private int tope;

	public PilaEnemigo() {
		this.tope = -1;
	}
	public boolean esVacia(){
		if(this.tope == -1)
			return true;
		else
			return false;
	}
	public boolean esLlena(){
		if(this.tope == max-1)
			return true;
		else 
			return false;
	}
	public void adi(Enemigo elem){
		if(!esLlena()){
			this.tope++;
			this.v[this.tope] = elem;
		}
		else
			System.out.println("Pila Llena!!!");
	}
	public Enemigo eli(){
		Enemigo elem;
		if(!esVacia()){
			elem = this.v[this.tope];
			this.tope--;
            return elem;
		}
		else{
            System.out.println("Pila es vacia!!!!");
            return null;
        }

	}
	
	public void mostrar(){
		PilaEnemigo aux = new PilaEnemigo();
		System.out.println("Datos de la pila: ");
		while(!esVacia()){
			Enemigo elem = eli();
			//System.out.println(elem);
			elem.mostrar();
			aux.adi(elem);
		} 
		vaciar(aux);
	}
	public void vaciar(PilaEnemigo p){
		while(!p.esVacia()){  //mientras la pila p NO es vacia
			this.adi(p.eli());
		}
	}
    /*
	public void llenar(int n){
		Scanner lee = new Scanner(System.in);
		System.out.println("Intr datos nombre, materia");
		for (int i = 1; i <= n; i++) {
			String nombre = lee.next();
			String materia = lee.next();
					
			Tarea elem = new Tarea(nombre, materia);
			//char elem = lee.next().charAt(0);
			this.adi(elem);
		}
	}
	*/
	public int nroElem(){
		return tope + 1;
	}
}
