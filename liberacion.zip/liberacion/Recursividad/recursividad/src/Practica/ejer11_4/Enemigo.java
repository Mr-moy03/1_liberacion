package Practica.ejer11_4;

public class Enemigo {
    private String idEnemigo;
    private String tipo;
    private int vida;

    public Enemigo(String idEnemigo,String tipo, int vida){
        this.idEnemigo = idEnemigo;
        this.tipo = tipo;
        this.vida = vida;
    }

    public String getIdEnemigo() {
        return idEnemigo;
    }

    public void setIdEnemigo(String idEnemigo) {
        this.idEnemigo = idEnemigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    @Override
    public String toString(){
        return String.format("[ID_Enemigo: %s, Tipo: %s, Vida: %d",getIdEnemigo(),getTipo(),getVida());
    }
    public void mostrar(){
        System.out.println(toString());
    }
}
