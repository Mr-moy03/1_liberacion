package Practica.ejer11_4;

import Practica.ejer11_3.PilaChar;

public class main {
    public static void main(String[] args) {
        Enemigo e1 = new Enemigo("123","mago",100);

        Enemigo e2 = new Enemigo("1235","Jefe",70);

        Enemigo e3 = new Enemigo("1236","Zorro",10);

        Enemigo e4 = new Enemigo("1237","Mujer",200);

        PilaEnemigo pilaE_1 = new PilaEnemigo();
        pilaE_1.adi(e1);
        pilaE_1.adi(e2);
        pilaE_1.adi(e3);
        pilaE_1.adi(e4);

        System.out.println(existeJefe(pilaE_1));

        System.out.println(totalVida(pilaE_1));



    }

    public static boolean existeJefe(PilaEnemigo P) {
        if (P.esVacia()) {
            return false; // Caso Base: Pila vacía, no se encontró
        } else {
            Enemigo aux = P.eli();
            boolean res = existeJefe(P); // Llamada recursiva

            if (aux.getTipo().equals("Jefe")) {
                res = true;
            }

            P.adi(aux); // Restaurar Pila
            return res;
        }
    }

    public static int totalVida(PilaEnemigo P) {
        if (P.esVacia()) {
            return 0; // Caso Base
        } else {
            Enemigo aux = P.eli();
            int suma = (int)(aux.getVida() + totalVida(P)); // Suma recursiva
            P.adi(aux); // Restaurar Pila
            return suma;
        }
    }
}
