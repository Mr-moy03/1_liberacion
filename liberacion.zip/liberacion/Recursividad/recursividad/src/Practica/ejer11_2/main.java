package Practica.ejer11_2;

public class main {
    public static void main(String[] args){
        numeros(7);
    }

    public static void numeros(int n) {
        if (n != 0) {
            numeros(n - 1);
            System.out.print(n + ",");
        }
    }


}


