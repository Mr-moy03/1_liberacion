public class ListaSimpleEmpleado {
	protected NodoEmpleado P;
	public ListaSimpleEmpleado() {
		P = null;
	}
	public NodoEmpleado getP() {
		return P;
	}
	public void setP(NodoEmpleado p) {
		P = p;
	}
	
}
