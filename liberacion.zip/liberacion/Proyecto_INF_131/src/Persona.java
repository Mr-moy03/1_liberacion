public class Persona {
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String ci;
    private int telefono;
    private int edad;
    private String genero;

    public Persona(String nombre,String apPaterno,String apMaterno,String ci,int telefono,int edad,String genero){
        this.nombre = nombre;
        this.apPaterno = apPaterno;
        this.apMaterno = apMaterno;
        this.ci = ci;
        this.telefono = telefono;
        this.edad = edad;
        this.genero = genero;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }

    public String getCi() {
        return ci;
    }

    public void setCi(String ci) {
        this.ci = ci;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("Persona:\n");
        s.append(String.format("> Nombre: %s\n",nombre));
        s.append(String.format("> Ap.Paterno: %s\n",apPaterno));
        s.append(String.format("> Ap.Materno: %s\n",apMaterno));
        s.append(String.format("> Ci: %s\n",ci));
        s.append(String.format("> Edad: %d\n",edad));
        s.append(String.format("> Telefono: %d\n",telefono));
        s.append(String.format("> Genero: %s\n",genero));

        return s.toString();
    }
    public void mostrar(){
        System.out.println(toString());
    }

}
