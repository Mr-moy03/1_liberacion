public class NodoEmpleado {
	private Empleado empl;
	private NodoEmpleado sig;
	
	public NodoEmpleado() {  //constructor
		sig = null;
	}

	public Empleado getEmpl() {
		return empl;
	}

	public void setEmpl(Empleado empl) {
		this.empl = empl;
	}

	public NodoEmpleado getSig() {
		return sig;
	}

	public void setSig(NodoEmpleado sig) {
		this.sig = sig;
	}
	
}
