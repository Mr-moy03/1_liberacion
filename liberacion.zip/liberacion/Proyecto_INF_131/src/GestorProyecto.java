public class GestorProyecto {
    private LS_NormalProyecto proyectos;

    public GestorProyecto() {
        this.proyectos = new LS_NormalProyecto();
    }

    public GestorProyecto(LS_NormalProyecto listaProyectos) {
        this.proyectos = listaProyectos;
    }

    public LS_NormalProyecto getProyectos() {
        return proyectos;
    }

    public void setProyectos(LS_NormalProyecto proyectos) {
        this.proyectos = proyectos;
    }

    public void agregarProyecto(Proyecto proyecto) {
        if (proyecto != null) {
            proyectos.adiFinal(proyecto);
            System.out.println("Proyecto '" + proyecto.getTitulo() + "' agregado al gestor.");
        }
    }

    public void eliminarProyecto(Proyecto proyecto) {
        if (proyecto == null) {
            System.out.println("Error: El proyecto a eliminar no puede ser nulo.");
            return;
        }

        LS_NormalProyecto aux = new LS_NormalProyecto();
        boolean eliminado = false;
        while (!proyectos.esVacia()) {
            NodoProyecto nodo = proyectos.eliPrincipio();
            if (nodo.getMa().getId_proyecto() != proyecto.getId_proyecto()) {
                aux.adiFinal(nodo.getMa());
            } else {
                eliminado = true;
            }
        }
        proyectos.setP(aux.getP()); // Restaura la lista de proyectos

        if (eliminado) {
            System.out.println("Proyecto '" + proyecto.getTitulo() + "' eliminado.");
        } else {
            System.out.println("No se encontró el proyecto '" + proyecto.getTitulo() + "' para eliminar.");
        }
    }

    public void mostrar() {
        this.listarProyectos();
    }

    public void listarProyectos() {
        if (proyectos.esVacia()) {
            System.out.println("No hay proyectos registrados en el gestor.");
        } else {
            System.out.println("=== Lista de Todos los Proyectos ===");
            proyectos.mostrar();
        }
    }

    public void asignarEmpleadoAProyecto(Empleado e, Proyecto p, Equipo eq) {
        Proyecto proyecto = buscarProyecto(p.getId_proyecto());

        if (proyecto == null) {
            System.out.println("Error: El proyecto '" + p.getTitulo() + "' no se encuentra en el gestor.");
            return;
        }

        ColaCircularEquipo aux = new ColaCircularEquipo();
        boolean equipoEncontrado = false;
        while (!proyecto.getEquipos().esVacia()) {
            Equipo equipo = proyecto.getEquipos().pop();
            if (equipo.getIdEquipo() == eq.getIdEquipo()) {
                equipo.getLista_empleado().adiFinal(e);
                equipoEncontrado = true;
            }
            aux.push(equipo);
        }
        proyecto.getEquipos().vaciar(aux);

        if (equipoEncontrado) {
            System.out.println("Empleado '" + e.getNombre() + "' asignado al equipo '" + eq.getNombre() + "' en el proyecto '" + p.getTitulo() + "'.");
        } else {
            System.out.println("Error: No se pudo encontrar el equipo '" + eq.getNombre() + "' en el proyecto '" + p.getTitulo() + "'.");
        }
    }

    public void buscarProyectoPorID(int id) {
        Proyecto p = buscarProyecto(id); // Reutiliza el método de búsqueda que retorna Proyecto
        if (p != null) {
            System.out.println("--- Mostrando detalles del proyecto " + id + " ---");
            p.mostrar();
        } else {
            System.out.println("No se encontró ningún proyecto con el ID " + id + ".");
        }
    }

    public Proyecto buscarProyecto(int idProyecto) {
        NodoProyecto R = proyectos.getP();
        while (R != null) {
            if (R.getMa().getId_proyecto() == idProyecto) {
                return R.getMa();
            }
            R = R.getSig();
        }
        return null;
    }

    public void generarReporteProyectosActivos() {
        System.out.println("--- Reporte de Proyectos Activos ---");
        LS_NormalProyecto activos = obtenerProyectosActivos();

        if (activos.esVacia()) {
            System.out.println("No se encontraron proyectos activos.");
        } else {
            activos.mostrar();
        }
    }

    public LS_NormalProyecto obtenerProyectosActivos() {
        LS_NormalProyecto activos = new LS_NormalProyecto();
        NodoProyecto R = proyectos.getP();
        while (R != null) {
            if (R.getMa().getEstado().equalsIgnoreCase("Activo")) {
                activos.adiFinal(R.getMa());
            }
            R = R.getSig();
        }
        return activos;
    }

    public Proyecto buscarProyectoPorTitulo(String titulo) {
        NodoProyecto R = proyectos.getP();
        while (R != null) {
            if (R.getMa().getTitulo().equalsIgnoreCase(titulo)) {
                return R.getMa();
            }
            R = R.getSig();
        }
        return null;
    }

    public int getCantidadProyectos() {
        return proyectos.nroNodos();
    }

    public void modificarProyecto(int idProyecto, String nuevoTitulo, String nuevoEstado) {
        Proyecto proyecto = buscarProyecto(idProyecto);
        if (proyecto != null) {
            proyecto.setTitulo(nuevoTitulo);
            proyecto.setEstado(nuevoEstado);
            System.out.println("Proyecto modificado exitosamente.");
        } else {
            System.out.println("Proyecto no encontrado.");
        }
    }

    public void verDetallesProyecto(int idProyecto) {
        Proyecto p = buscarProyecto(idProyecto);
        if (p != null) {
            p.mostrar();
        } else {
            System.out.println("Error: No se encontró el proyecto con ID " + idProyecto);
        }
    }

    public void generarReporteEstadoGlobal() {
        System.out.println("\n=== REPORTE GLOBAL DE ESTADO DE PROYECTOS ===");
        NodoProyecto actual = proyectos.getP();
        while (actual != null) {
            Proyecto p = actual.getMa();
            System.out.println("Proyecto: " + p.getTitulo() + " [ID: " + p.getId_proyecto() + "]");
            System.out.println("  - Estado: " + p.getEstado());
            System.out.println("  - Progreso: " + p.obtener_progreso() + "%");
            System.out.println("  - Tareas Pendientes: " + p.getTareas_pendientes().nroElem());
            System.out.println("  - Tareas Activas: " + p.getTareas_activas().nroElem());
            System.out.println("  - Tareas Finalizadas: " + p.getTareas_finalizadas().nroElem());
            System.out.println("---------------------------------------------");
            actual = actual.getSig();
        }
    }
}