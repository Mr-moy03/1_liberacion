import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GestorProyecto gestor = new GestorProyecto();

        // 1.DATOS (OBJETOS REALES)

        System.out.println("Cargando datos del sistema...");

        // --- 1.1 Empleados (5 empleados individuales) ---
        PilaTarea pilaEmp1 = new PilaTarea();
        Empleado empl1 = new Empleado("Juan", "Perez", "Garcia", "1001", 77200100, 30, "M", "EMP01", "Dev Backend", 5000, "Sistemas", pilaEmp1);

        PilaTarea pilaEmp2 = new PilaTarea();
        Empleado empl2 = new Empleado("Ana", "Lopez", "Mendez", "1002", 77200200, 28, "F", "EMP02", "Dev Frontend", 5000, "Sistemas", pilaEmp2);

        PilaTarea pilaEmp3 = new PilaTarea();
        Empleado empl3 = new Empleado("Carlos", "Mamani", "Quispe", "1003", 77200300, 35, "M", "EMP03", "QA Tester", 4500, "Calidad", pilaEmp3);

        PilaTarea pilaEmp4 = new PilaTarea();
        Empleado empl4 = new Empleado("Sofia", "Arze", "Vargas", "1004", 77200400, 29, "F", "EMP04", "Diseñador UX", 4800, "Diseño", pilaEmp4);

        PilaTarea pilaEmp5 = new PilaTarea();
        Empleado empl5 = new Empleado("Pedro", "Aliaga", "Sossa", "1005", 77200500, 40, "M", "EMP05", "Project Manager", 8000, "Gerencia", pilaEmp5);

        // --- 1.2 Listas de Empleados para Equipos ---
        LS_NormalEmpleado listaEquipoA = new LS_NormalEmpleado();
        listaEquipoA.adiFinal(empl1);
        listaEquipoA.adiFinal(empl2);

        LS_NormalEmpleado listaEquipoB = new LS_NormalEmpleado();
        listaEquipoB.adiFinal(empl3);
        listaEquipoB.adiFinal(empl4);

        // --- 1.3 Equipos ---
        PilaTarea pilaEqA = new PilaTarea();
        Equipo equipoA = new Equipo("EQ01", "Alpha Devs", pilaEqA, listaEquipoA);

        PilaTarea pilaEqB = new PilaTarea();
        Equipo equipoB = new Equipo("EQ02", "Beta Testers", pilaEqB, listaEquipoB);

        // --- 1.4 Tareas ---
        Tarea t1 = new Tarea("T01", "Diseñar Base de Datos", "Alta", "Pendiente", "Modelo ER y Relacional", "18/11/25", "20/11/25");
        Tarea t2 = new Tarea("T02", "Crear Login", "Media", "Pendiente", "Login con JWT", "18/11/25", "22/11/25");
        Tarea t3 = new Tarea("T03", "Pruebas Unitarias", "Baja", "Pendiente", "Testear servicios", "25/11/25", "28/11/25");
        Tarea t4 = new Tarea("T04", "Interfaz Usuario", "Muy Alta", "Pendiente", "Diseño en Figma", "19/11/25", "21/11/25");
        Tarea t5 = new Tarea("T05", "Documentacion", "Baja", "Pendiente", "Manual de usuario", "30/11/25", "05/12/25");

        Tarea t6 = new Tarea("T06", "Plan de Marketing", "Alta", "Pendiente", "Redes sociales", "01/12/25", "10/12/25");

        // --- 1.5 Estructuras para Proyectos ---
        // Proyecto 1: Sistema Web
        ColaCircularEquipo colaEquiposP1 = new ColaCircularEquipo();
        colaEquiposP1.push(equipoA);
        colaEquiposP1.push(equipoB);

        ColaCircularTareasPendientes pendientesP1 = new ColaCircularTareasPendientes();
        pendientesP1.push(t1);
        pendientesP1.push(t2);
        pendientesP1.push(t4); // Muy Alta
        pendientesP1.push(t3); // Baja

        ColaCircularTareasActivas activasP1 = new ColaCircularTareasActivas(); // Inicialmente vacía
        ColaCircularTareasFinalizadas finP1 = new ColaCircularTareasFinalizadas(); // Inicialmente vacía
        PilaActualizacion actualizacionesP1 = new PilaActualizacion();

        Proyecto proy1 = new Proyecto(1, "Sistema E-Commerce", "Activo", colaEquiposP1, pendientesP1, activasP1, finP1, actualizacionesP1);

        // Proyecto 2: Campaña Publicitaria
        ColaCircularEquipo colaEquiposP2 = new ColaCircularEquipo();


        ColaCircularTareasPendientes pendientesP2 = new ColaCircularTareasPendientes();
        pendientesP2.push(t5);
        pendientesP2.push(t6);

        Proyecto proy2 = new Proyecto(2, "Campaña Navidad", "Planificacion", colaEquiposP2, pendientesP2, new ColaCircularTareasActivas(), new ColaCircularTareasFinalizadas(), new PilaActualizacion());

        // --- 1.6 Agregar al Gestor ---
        gestor.agregarProyecto(proy1);
        gestor.agregarProyecto(proy2);


        // MENU DE APLICACION

        int opcion = 0;
        Proyecto proyectoActual = proy1;

        while (opcion != 9) {
            System.out.println("\n#############################################");
            System.out.println(" SISTEMA GESTOR DE PROYECTOS COLABORATIVOS");
            System.out.println(" Proyecto Actual: " + proyectoActual.getTitulo() + " (ID: " + proyectoActual.getId_proyecto() + ")");
            System.out.println("#############################################");
            System.out.println("1. Cambiar Proyecto Activo (Prob 4)");
            System.out.println("2. Ver Estado del Proyecto Actual");
            System.out.println("3. Organizar Tareas por Prioridad (Prob 1)");
            System.out.println("4. Asignar Empleado a Tarea (Prob 2)");
            System.out.println("5. Registrar Avance de Tarea (Prob 3)");
            System.out.println("6. Ver Historial de Actualizaciones");
            System.out.println("7. Generar Reporte Global de Proyectos (Prob 5)");
            System.out.println("8. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                opcion = 0;
            }

            switch (opcion) {
                case 1: // PROBLEMA 4
                    System.out.println("\n-- Proyectos Disponibles --");
                    gestor.listarProyectos();
                    System.out.print("Ingrese ID del proyecto a seleccionar: ");
                    int idSel = Integer.parseInt(scanner.nextLine());
                    Proyecto pSel = gestor.buscarProyecto(idSel);
                    if (pSel != null) {
                        proyectoActual = pSel;
                        System.out.println("Ahora trabajando en: " + proyectoActual.getTitulo());
                    } else {
                        System.out.println("ID no encontrado.");
                    }
                    break;

                case 2:
                    proyectoActual.mostrar();
                    break;

                case 3: // PROBLEMA 1
                    System.out.println("\nOrganizando tareas pendientes por prioridad...");
                    proyectoActual.organizarTareasPorPrioridad();
                    break;

                case 4: // PROBLEMA 2
                    System.out.print("Ingrese ID de la Tarea (ej. T01): ");
                    String idT = scanner.nextLine();
                    System.out.print("Ingrese CI del Empleado (ej. 1001): ");
                    String ciE = scanner.nextLine();

                    // Requiere método asignarResponsableUnico() en Proyecto
                    proyectoActual.asignarResponsableUnico(idT, ciE);
                    break;

                case 5: // PROBLEMA 3
                    System.out.print("Ingrese ID de la Tarea a actualizar: ");
                    String idTask = scanner.nextLine();
                    System.out.print("Ingrese CI del responsable que reporta: ");
                    String ciResp = scanner.nextLine();
                    System.out.print("Descripción del avance: ");
                    String desc = scanner.nextLine();
                    System.out.print("Porcentaje de avance (0-100): ");
                    int porc = Integer.parseInt(scanner.nextLine());
                    proyectoActual.registrarAvance(idTask, ciResp, desc, porc);
                    break;

                case 6:
                    proyectoActual.verHistorialActualizaciones();
                    break;

                case 7: // PROBLEMA 5
                    gestor.generarReporteEstadoGlobal();
                    break;

                case 8:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        }
        scanner.close();
    }
}