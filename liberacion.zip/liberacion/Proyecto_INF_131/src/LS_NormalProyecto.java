public class LS_NormalProyecto extends ListaSimpleProyecto {

	public LS_NormalProyecto() {
		super();
	}

	public boolean esVacia() {
		if(P == null)
			return true;
		return false;
	}

	public void adiPrincipio(Proyecto z) {
		NodoProyecto nuevo = new NodoProyecto();
		nuevo.setMa(z);
		nuevo.setSig(P);
		P = nuevo;
	}
	
	public void adiFinal(Proyecto z) {
		NodoProyecto nuevo = new NodoProyecto();
		nuevo.setMa(z);
		
		if(esVacia())
			P = nuevo;   //p apunta a nuevo
		else {
			NodoProyecto R = P;
			while( R.getSig() != null ){
			     R = R.getSig();
			}
			R.setSig(nuevo);
		}
	}
	
	
	public void mostrar() {
		NodoProyecto R = P;
		while(R != null) {
			R.getMa().mostrar();
			R = R.getSig();
		}
	}

	public int nroNodos() {
		NodoProyecto R = P;
		int c = 0;
		if(this.esVacia())
			return 0;
		else {
			while(R != null) {
				c++;
				R = R.getSig();
			}
		}
		return c;
	}
	
	public NodoProyecto eliPrincipio() {
		NodoProyecto x = null;
		if(!esVacia()) {
			x = P ;
			P = P.getSig();
			x.setSig(null);
		}
		return x;
	}
	
	public NodoProyecto eliFinal() {
		NodoProyecto x = null;
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;
				P = null;
			}else {
				NodoProyecto R = P;
				NodoProyecto S = P;
				while(R.getSig() != null) {
					S = R;
					R = R.getSig();
				}
				x = R;
				S.setSig(null);
			}
		}
		return x;
	}
	/*
	public void leer1(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiPrincipio(z);
		}
	}
	
	public void leer2(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiFinal(z);
		}
	}*/
}
