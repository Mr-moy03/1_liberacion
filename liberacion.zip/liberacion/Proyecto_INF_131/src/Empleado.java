public class Empleado extends Persona {
    private String idEmpleado;
    private String cargo;
    private double salario;
    private String departamento;
    private PilaTarea ptarea;

    public Empleado(String nombre,String apPaterno,String apMaterno,String ci,int telefono,int edad,String genero, String idEmpleado, String cargo, double salario,String departamento,PilaTarea ptarea) {
        super(nombre, apPaterno,apMaterno,ci,telefono,edad,genero);
        this.idEmpleado = idEmpleado;
        this.cargo = cargo;
        this.salario = salario;
        this.departamento = departamento;
        this.ptarea = ptarea;
    }

    public String getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(String idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public PilaTarea getPtarea() {
        return ptarea;
    }

    public void setPtarea(PilaTarea ptarea) {
        this.ptarea = ptarea;
    }

    @Override
    public String toString(){
        StringBuilder s = new StringBuilder();
        s.append("Empleado:\n");
        s.append(String.format("> ID Empleado: %s\n",idEmpleado));
        s.append(String.format("> Nombre: %s\n",getNombre()));
        s.append(String.format("> Ap.Paterno: %s\n",getApPaterno()));
        s.append(String.format("> Ap.Materno: %s\n",getApPaterno()));
        s.append(String.format("> Ci: %s\n",getCi()));
        s.append(String.format("> Edad: %s\n",getCi()));
        s.append(String.format("> Telefono: %d\n",getTelefono()));
        s.append(String.format("> Genero: %s\n",getGenero()));
        return s.toString();

    }
    public void mostrar() {
        System.out.println(toString());
        ptarea.mostrar();
    }

    public int calcularCargaTrabajo() {
        return this.ptarea.nroElem();
    }


    public void listarTareasPorEstado() {

        PilaTarea aux = new PilaTarea();
        PilaTarea t_pendientes = new PilaTarea();
        PilaTarea t_activas= new PilaTarea();
        PilaTarea t_finalizadas= new PilaTarea();
        while(!this.ptarea.esVacia()){
            Tarea elem = this.ptarea.eli();

            if(elem.getEstado()=="pendiente") {
                t_pendientes.adi(elem);
            }else if(elem.getEstado()=="activa") {
                t_activas.adi(elem);
            }else if(elem.getEstado()=="finalizada"){
                t_finalizadas.adi(elem);
            }else {
                System.out.println("Que estado es ese???");
            }

            aux.adi(elem);
        }
        this.ptarea.vaciar(aux);

        System.out.println("Tareas Pendientes:");
        t_pendientes.mostrar();
        System.out.println("\nTareas Activas:");
        t_activas.mostrar();
        System.out.println("\nTareas Finalizadas:");
        t_finalizadas.mostrar();
    }


    public void reportarAvanceTareas() {

        int nroTactivas =0;
        int nroTfinalizadas =0;

        PilaTarea aux = new PilaTarea();

        while(!this.ptarea.esVacia()){
            Tarea elem = this.ptarea.eli();

            if(elem.getEstado()=="activa") {
                nroTactivas += 1;
            }else if(elem.getEstado()=="finalizada") {
                nroTfinalizadas +=1;
            }

            aux.adi(elem);
        }
        this.ptarea.vaciar(aux);

        System.out.println(nroTfinalizadas +" de"+ nroTactivas +" fueron terminadas");
    }
}