public class ColaCircularEquipo {
    protected int MAX = 50;
    protected Equipo[] v = new Equipo[MAX];
    protected int fr;
    protected int fi;

    public ColaCircularEquipo() {
        this.fr = 0;
        this.fi = 0;
    }

    public int nroElem() {
        return (fi - fr + MAX) % MAX;
    }
    public boolean esVacia() {
        if(nroElem() == 0)
            return true;
        return false;

    }
    public boolean esLlena() {
        if(nroElem() == MAX-1)
            return true;
        return false;
    }
    public void push(Equipo elem) {
        if(!esLlena()) {
            fi = (fi + 1) % MAX;
            v[fi] = elem;
        }else
            System.out.println("cola circular llena!!!");
    }
    public Equipo pop() {
        Equipo elem;
        if(!esVacia()) {
            fr = (fr + 1) % MAX;
            elem = v[fr];
            return elem;
        }else {
            System.out.println("Cola circular vacia!!");
            return null;
        }
    }

    public void vaciar(ColaCircularEquipo z) {
        while(!z.esVacia()) {
            push(z.pop());
        }
    }

    public void mostrar() {
        ColaCircularEquipo aux = new ColaCircularEquipo();
        while(!esVacia()) {
            Equipo elem = pop();
            elem.mostrar();
            aux.push(elem);
        }
        vaciar(aux);
    }
}


