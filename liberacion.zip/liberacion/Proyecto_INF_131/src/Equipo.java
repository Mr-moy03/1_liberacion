public class Equipo {
    private String nombre;
    private LS_NormalEmpleado lista_empleado;
    private String idEquipo;
    private PilaTarea tareas_asignadas;
    Equipo(String idEquipo, String nombre, PilaTarea tareas_asignadas, LS_NormalEmpleado lista_empleado){
        this.idEquipo=idEquipo;
        this.lista_empleado=lista_empleado;
        this.nombre=nombre;
        this.tareas_asignadas=tareas_asignadas;
    }

    public String getIdEquipo() {
        return idEquipo;
    }

    public LS_NormalEmpleado getLista_empleado() {
        return lista_empleado;
    }

    public PilaTarea getTareas_asignadas() {
        return tareas_asignadas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setIdEquipo(String idEquipo) {
        this.idEquipo = idEquipo;
    }

    public void setLista_empleado(LS_NormalEmpleado lista_empleado) {
        this.lista_empleado = lista_empleado;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTareas_asignadas(PilaTarea tareas_asignadas) {
        this.tareas_asignadas = tareas_asignadas;
    }
    public void mostrar(){
        System.out.println("El nombre delequipo es "+nombre+" y tiene de ID "+idEquipo+" ");
        System.out.println("Los empleados del equipo son \t");
        lista_empleado.mostrar();
        System.out.println("Las tareas asignadas al equipo son \t");
        tareas_asignadas.mostrar();
    }
    public void agregarEmpleado(Empleado e){
        lista_empleado.adiFinal(e);
    }
    public void eliminarEmpleado(String nom){
        NodoEmpleado R= lista_empleado.getP();
        NodoEmpleado G= null;

        while (R.getSig() != null){
            if(R.getEmpl().getNombre().equals(nom)){
                if (G==null){
                    lista_empleado.setP(R.getSig());
                }
                else {
                    G.setSig(R.getSig());
                }
            }
        }
        G = R;
        R = R.getSig();
    }
}