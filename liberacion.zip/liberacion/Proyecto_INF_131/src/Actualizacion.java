public class Actualizacion {
    private int nro_actualizacion;
    private String descripcion;
    private Empleado responsable;
    private String fecha;
    private String hora;
    private Tarea tarea_trabajada;

    public Actualizacion(int nro_actualizacion,String descripcion, Empleado responsable,String fecha,String hora, Tarea tarea_trabajada) {
        this.nro_actualizacion = nro_actualizacion;
        this.descripcion = descripcion;
        this.responsable = responsable;
        this.fecha = fecha;
        this.hora = hora;
        this.tarea_trabajada = tarea_trabajada;
    }


    public int getNro_actualizacion() {
        return nro_actualizacion;
    }

    public void setNro_actualizacion(int nro_actualizacion) {
        this.nro_actualizacion = nro_actualizacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Empleado getResponsable() {
        return responsable;
    }

    public void setResponsable(Empleado responsable) {
        this.responsable = responsable;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Tarea getTarea_trabajada() {
        return tarea_trabajada;
    }

    public void setTarea_trabajada(Tarea tarea_trabajada) {
        this.tarea_trabajada = tarea_trabajada;
    }

    public void mostrar(){
        System.out.println("Actualizaciones");
        this.tarea_trabajada.mostrar();
    }
}