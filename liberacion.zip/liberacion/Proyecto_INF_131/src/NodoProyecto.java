public class NodoProyecto {
	private Proyecto proy;
	private NodoProyecto sig;

	public NodoProyecto() {  //constructor
		sig = null;
	}

	public Proyecto getMa() {
		return proy;
	}

	public void setMa(Proyecto proy) {
		this.proy = proy;
	}

	public NodoProyecto getSig() {
		return sig;
	}

	public void setSig(NodoProyecto sig) {
		this.sig = sig;
	}
	
}
