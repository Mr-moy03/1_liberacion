public class LS_NormalEmpleado extends ListaSimpleEmpleado {

	public LS_NormalEmpleado() {
		super();
	}

	public boolean esVacia() {
		if(P == null)
			return true;
		return false;
	}

	public void adiPrincipio(Empleado z) {
		NodoEmpleado nuevo = new NodoEmpleado(); //composicion
		nuevo.setEmpl(z);
		nuevo.setSig(P); //el siguiente del nodo nuevo apunta a nodo raiz
		P = nuevo;      //P apunta a nuevo
	}
	
	public void adiFinal(Empleado z) {
		NodoEmpleado nuevo = new NodoEmpleado();
		nuevo.setEmpl(z);
		
		if(esVacia())
			P = nuevo;   //p apunta a nuevo
		else {
			NodoEmpleado R = P;
			while( R.getSig() != null ){
			     R = R.getSig();
			}
			R.setSig(nuevo);
		}
	}
    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        NodoEmpleado R = P;
        while(R != null) {
            s.append(R.getEmpl());
            //R.getEmpl().mostrar();
            R = R.getSig();
        }
        return s.toString();
    }

    public void mostrar() {
        System.out.println(toString());
    }

	public int nroNodos() {
		NodoEmpleado R = P;
		int c = 0;
		if(this.esVacia())
			return 0;
		else {
			while(R != null) {
				c++;
				R = R.getSig();
			}
		}
		return c;
	}
	
	public NodoEmpleado eliPrincipio() {
		NodoEmpleado x = null;
		if(!esVacia()) {
			x = P ;     // x apunta a la raiz P
			P = P.getSig();
			x.setSig(null);
		}
		return x;
	}
	
	public NodoEmpleado eliFinal() {
		NodoEmpleado x = null;
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;      //x apunta a la raiz P
				P = null;
			}else {
				NodoEmpleado R = P;
				NodoEmpleado S = P;
				while(R.getSig() != null) {
					S = R;         //S apunta a R
					R = R.getSig(); //R apunta al siguiente de R
				}
				x = R;
				S.setSig(null);
			}
		}
		return x;
	}
	/*
	public void leer1(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiPrincipio(z);
		}
	}
	
	public void leer2(int n) {
		for (int i = 1; i <= n; i++) {
			Empleado z = new Empleado();
			z.leer();
			adiFinal(z);
		}
	}*/
}
