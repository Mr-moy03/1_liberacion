import java.util.Objects;

public class Proyecto {

    private int id_proyecto;
    private String titulo;
    private String estado;
    private ColaCircularEquipo equipos;
    private ColaCircularTareasPendientes tareas_pendientes;
    private ColaCircularTareasActivas tareas_activas;
    private ColaCircularTareasFinalizadas tareas_finalizadas;
    private PilaActualizacion pActualizacion;


    public Proyecto(int id_proyecto, String titulo, String estado, ColaCircularEquipo equipos,
                    ColaCircularTareasPendientes tareas_pendientes, ColaCircularTareasActivas tareas_activas,
                    ColaCircularTareasFinalizadas tareas_finalizadas, PilaActualizacion pActualizacion) {

        this.id_proyecto = id_proyecto;
        this.titulo = titulo;
        this.estado = estado;
        this.equipos = equipos;
        this.tareas_pendientes = tareas_pendientes;
        this.tareas_activas = tareas_activas;
        this.tareas_finalizadas = tareas_finalizadas;
        this.pActualizacion = pActualizacion;
    }


    public int getId_proyecto() {
        return id_proyecto;
    }

    public void setId_proyecto(int id_proyecto) {
        this.id_proyecto = id_proyecto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ColaCircularEquipo getEquipos() {
        return equipos;
    }

    public void setEquipos(ColaCircularEquipo equipos) {
        this.equipos = equipos;
    }

    public ColaCircularTareasPendientes getTareas_pendientes() {
        return tareas_pendientes;
    }

    public void setTareas_pendientes(ColaCircularTareasPendientes tareas_pendientes) {
        this.tareas_pendientes = tareas_pendientes;
    }

    public ColaCircularTareasActivas getTareas_activas() {
        return tareas_activas;
    }

    public void setTareas_activas(ColaCircularTareasActivas tareas_activas) {
        this.tareas_activas = tareas_activas;
    }

    public ColaCircularTareasFinalizadas getTareas_finalizadas() {
        return tareas_finalizadas;
    }

    public void setTareas_finalizadas(ColaCircularTareasFinalizadas tareas_finalizadas) {
        this.tareas_finalizadas = tareas_finalizadas;
    }

    public PilaActualizacion getpActualizacion() {
        return pActualizacion;
    }

    public void setpActualizacion(PilaActualizacion pActualizacion) {
        this.pActualizacion = pActualizacion;
    }

    public void mostrar() {
        System.out.println("=============================================");
        System.out.println("PROYECTO: " + titulo.toUpperCase());
        System.out.println("=============================================");
        System.out.println("ID: " + id_proyecto);
        System.out.println("Estado: " + estado);
        System.out.println("Progreso: " + obtener_progreso() + "%");

        System.out.println("\n--- Equipos Asignados ---");
        if (equipos.esVacia()) {
            System.out.println("Sin equipos asignados.");
        } else {
            equipos.mostrar();
        }

        System.out.println("\n--- Tareas Pendientes (" + tareas_pendientes.nroElem() + ") ---");
        if (tareas_pendientes.esVacia()) {
            System.out.println("No hay tareas pendientes.");
        } else {
            tareas_pendientes.mostrar();
        }

        System.out.println("\n--- Tareas Activas (" + tareas_activas.nroElem() + ") ---");
        if (tareas_activas.esVacia()) {
            System.out.println("No hay tareas activas.");
        } else {
            tareas_activas.mostrar();
        }

        System.out.println("\n--- Tareas Finalizadas (" + tareas_finalizadas.nroElem() + ") ---");
        if (tareas_finalizadas.esVacia()) {
            System.out.println("No hay tareas finalizadas.");
        } else {
            tareas_finalizadas.mostrar();
        }
        System.out.println("=============================================\n");
    }

    public void agregar_Equipo(Equipo equipo) {
        if (equipo != null) {
            this.equipos.push(equipo);
            System.out.println("Equipo '" + equipo.getNombre() + "' agregado al proyecto '" + this.titulo + "'.");
        }
    }

    public void remover_Equipo(String idEquipo) {
        ColaCircularEquipo aux = new ColaCircularEquipo();
        boolean encontrado = false;
        while (!equipos.esVacia()) {
            Equipo e = equipos.pop();
            if (e.getIdEquipo() == idEquipo) {
                encontrado = true;
            } else {
                aux.push(e);
            }
        }
        equipos.vaciar(aux);

        if (encontrado) {
            System.out.println("Equipo con ID " + idEquipo + " eliminado del proyecto.");
        } else {
            System.out.println("No se encontró un equipo con ID " + idEquipo + " en este proyecto.");
        }
    }

    public void buscarTarea_Nombre(String nombreTarea) {
        boolean encontrado = false;
        Tarea t = null;

        ColaCircularTareasPendientes auxP = new ColaCircularTareasPendientes();
        while (!tareas_pendientes.esVacia()) {
            t = tareas_pendientes.pop();
            if (t.getNombre().equalsIgnoreCase(nombreTarea)) {
                t.mostrar();
                encontrado = true;
            }
            auxP.push(t);
        }
        tareas_pendientes.vaciar(auxP);

        ColaCircularTareasActivas auxA = new ColaCircularTareasActivas();
        while (!tareas_activas.esVacia() && !encontrado) {
            t = tareas_activas.pop();
            if (t.getNombre().equalsIgnoreCase(nombreTarea)) {
                t.mostrar();
                encontrado = true;
            }
            auxA.push(t);
        }
        tareas_activas.vaciar(auxA);

        ColaCircularTareasFinalizadas auxF = new ColaCircularTareasFinalizadas();
        while (!tareas_finalizadas.esVacia() && !encontrado) {
            t = tareas_finalizadas.pop();
            if (t.getNombre().equalsIgnoreCase(nombreTarea)) {
                t.mostrar();
                encontrado = true;
            }
            auxF.push(t);
        }
        tareas_finalizadas.vaciar(auxF);

        if (!encontrado) {
            System.out.println("No se encontró ninguna tarea con el nombre '" + nombreTarea + "'.");
        }
    }

    public void cambiarPrioridad_Tarea(String nombreTarea, String nuevaPrioridad) {
        boolean encontrado = false;
        Tarea t = null;

        ColaCircularTareasPendientes auxP = new ColaCircularTareasPendientes();
        while (!tareas_pendientes.esVacia()) {
            t = tareas_pendientes.pop();
            if (t.getNombre().equalsIgnoreCase(nombreTarea)) {
                t.setPrioridad(nuevaPrioridad);
                encontrado = true;
            }
            auxP.push(t);
        }
        tareas_pendientes.vaciar(auxP);

        ColaCircularTareasActivas auxA = new ColaCircularTareasActivas();
        while (!tareas_activas.esVacia() && !encontrado) {
            t = tareas_activas.pop();
            if (t.getNombre().equalsIgnoreCase(nombreTarea)) {
                t.setPrioridad(nuevaPrioridad);
                encontrado = true;
            }
            auxA.push(t);
        }
        tareas_activas.vaciar(auxA);


        if (encontrado) {
            System.out.println("Prioridad de la tarea '" + nombreTarea + "' actualizada a '" + nuevaPrioridad + "'.");
        } else {
            System.out.println("No se encontró una tarea activa o pendiente con el nombre '" + nombreTarea + "'.");
        }
    }

    public int obtener_progreso() {
        int nroPendientes = tareas_pendientes.nroElem();
        int nroActivas = tareas_activas.nroElem();
        int nroFinalizadas = tareas_finalizadas.nroElem();

        int total = nroPendientes + nroActivas + nroFinalizadas;

        if (total == 0) {
            return 0; // Evita división por cero
        }

        double progreso = (double) nroFinalizadas * 100.0 / total;
        return (int) progreso;
    }

    public void verHistorialActualizaciones() {
        System.out.println("--- Historial de Actualizaciones del Proyecto '" + this.titulo + "' ---");
        if (pActualizacion.esVacia()) {
            System.out.println("No hay actualizaciones registradas.");
        } else {
            pActualizacion.mostrar();
        }
    }


// PROBLEMA 1: Organizar por Prioridad
    public void organizarTareasPorPrioridad() {
        PilaTarea muyAlta = new PilaTarea();
        PilaTarea alta = new PilaTarea();
        PilaTarea media = new PilaTarea();
        PilaTarea baja = new PilaTarea();

        // Clasificar
        separarPorPrioridad(this.tareas_pendientes, muyAlta, alta, media, baja);
        // separarPorPrioridad(this.tareas_activas, muyAlta, alta, media, baja);

        // Reinsertar en orden: Muy Alta -> Alta -> Media -> Baja
        insertarPorPrioridad(muyAlta, this.tareas_pendientes);
        insertarPorPrioridad(alta, this.tareas_pendientes);
        insertarPorPrioridad(media, this.tareas_pendientes);
        insertarPorPrioridad(baja, this.tareas_pendientes);

        System.out.println("=== TAREAS ORGANIZADAS POR PRIORIDAD EN COLA PENDIENTES ===");
        this.tareas_pendientes.mostrar();
    }

    private void separarPorPrioridad(ColaCircularTareasPendientes cola, PilaTarea ma, PilaTarea a, PilaTarea m, PilaTarea b) {
        ColaCircularTareasPendientes aux = new ColaCircularTareasPendientes();
        while (!cola.esVacia()) {
            Tarea t = cola.pop();
            String p = t.getPrioridad().toLowerCase();
            if (p.equals("muy alta")) ma.adi(t);
            else if (p.equals("alta")) a.adi(t);
            else if (p.equals("media")) m.adi(t);
            else b.adi(t);
            aux.push(t);
        }
    }

    private void insertarPorPrioridad(PilaTarea pila, ColaCircularTareasPendientes cola) {
        while (!pila.esVacia()) {
            cola.push(pila.eli());
        }
    }


// PROBLEMA 2: Asignar Responsable Único
    public boolean asignarResponsableUnico(String idTarea, String ciEmpleado) {
        // 1. Buscar Tarea (asumimos que está en pendientes o activas)
        Tarea tarea = buscarTareaObjeto(idTarea);
        if (tarea == null) {
            System.out.println("Error: Tarea no encontrada.");
            return false;
        }

        // 2. Verificar si ya está asignado
        if (empleadoYaAsignado(tarea, ciEmpleado)) {
            System.out.println("Error: El empleado ya está asignado a esta tarea.");
            return false;
        }

        // 3. Buscar Empleado en los equipos del proyecto
        Empleado empleado = buscarEmpleadoEnEquipos(ciEmpleado);
        if (empleado == null) {
            System.out.println("Error: Empleado no pertenece a ningun equipo de este proyecto.");
            return false;
        }

        // 4. Validar carga de trabajo
        if (empleado.calcularCargaTrabajo() >= 5) {
            System.out.println("Advertencia: El empleado tiene alta carga de trabajo.");
        }

        // 5. Asignación
        tarea.getEncargadosTareas().adiFinal(empleado);
        empleado.getPtarea().adi(tarea);

        // 6. Registrar Actualización
        registrarActualizacion(tarea, empleado, "Asignación inicial de responsable.");

        // 7. Mover de Pendiente a Activa si estaba en pendiente
        moverTareaEntreColas(tarea, "pendiente", "activa");
        tarea.setEstado("Activa");

        System.out.println("Exito: " + empleado.getNombre() + " asignado a " + tarea.getNombre());
        return true;
    }

    private boolean empleadoYaAsignado(Tarea t, String ci) {
        NodoEmpleado actual = t.getEncargadosTareas().getP();
        while (actual != null) {
            if (actual.getEmpl().getCi().equals(ci)) return true;
            actual = actual.getSig();
        }
        return false;
    }

    private Empleado buscarEmpleadoEnEquipos(String ci) {
        ColaCircularEquipo aux = new ColaCircularEquipo();
        Empleado encontrado = null;
        while (!equipos.esVacia()) {
            Equipo e = equipos.pop();
            NodoEmpleado ne = e.getLista_empleado().getP();
            while (ne != null) {
                if (ne.getEmpl().getCi().equals(ci)) encontrado = ne.getEmpl();
                ne = ne.getSig();
            }
            aux.push(e);
        }
        equipos.vaciar(aux);
        return encontrado;
    }


// PROBLEMA 3: Registrar y Visualizar Avance
    public void registrarAvance(String idTarea, String ciEmpleado, String descripcion, int porcentaje) {
        Tarea tarea = buscarTareaObjeto(idTarea);
        Empleado emp = buscarEmpleadoEnEquipos(ciEmpleado);

        if (tarea != null && emp != null) {
            // Registrar actualización
            registrarActualizacion(tarea, emp, descripcion + " (" + porcentaje + "%)");

            // Lógica de movimiento según porcentaje
            if (porcentaje == 100) {
                tarea.setEstado("Finalizada");
                moverTareaEntreColas(tarea, "activa", "finalizada");
                moverTareaEntreColas(tarea, "pendiente", "finalizada"); // Por si acaso
            } else if (porcentaje > 0) {
                tarea.setEstado("En Progreso");
                moverTareaEntreColas(tarea, "pendiente", "activa");
            }
            System.out.println("Avance registrado correctamente.");
        } else {
            System.out.println("Error: Tarea o Empleado no válidos.");
        }
    }

    // Método auxiliar complejo para mover tareas entre colas circulares
    private void moverTareaEntreColas(Tarea t, String origen, String destino) {
        boolean encontrada = false;
        Tarea tareaMovida = null;

        // 1. Sacar de origen
        if (origen.equals("pendiente")) {
            ColaCircularTareasPendientes aux = new ColaCircularTareasPendientes();
            while(!tareas_pendientes.esVacia()){
                Tarea x = tareas_pendientes.pop();
                if(x.getId_tarea().equals(t.getId_tarea())){
                    tareaMovida = x;
                    encontrada = true;
                } else {
                    aux.push(x);
                }
            }
            tareas_pendientes.vaciar(aux);
        } else if (origen.equals("activa")) {
            ColaCircularTareasActivas aux = new ColaCircularTareasActivas();
            while(!tareas_activas.esVacia()){
                Tarea x = tareas_activas.pop();
                if(x.getId_tarea().equals(t.getId_tarea())){
                    tareaMovida = x;
                    encontrada = true;
                } else {
                    aux.push(x);
                }
            }
            tareas_activas.vaciar(aux);
        }

        // 2. Poner en destino (si fue encontrada)
        if (encontrada && tareaMovida != null) {
            if (destino.equals("activa")) tareas_activas.push(tareaMovida);
            else if (destino.equals("finalizada")) tareas_finalizadas.push(tareaMovida);
            else if (destino.equals("pendiente")) tareas_pendientes.push(tareaMovida);
        }
    }

    public Tarea buscarTareaObjeto(String id) {
        // Busca en las 3 colas (sin vaciarlas permanentemente)
        Tarea encontrada = null;
        // ... Lógica de búsqueda en pendientes ...
        ColaCircularTareasPendientes auxP = new ColaCircularTareasPendientes();
        while(!tareas_pendientes.esVacia()){
            Tarea t = tareas_pendientes.pop();
            if(t.getId_tarea().equals(id)) encontrada = t;
            auxP.push(t);
        }
        tareas_pendientes.vaciar(auxP);
        if(encontrada != null) return encontrada;

        // ... Repetir para Activas y Finalizadas ...
        ColaCircularTareasActivas auxA = new ColaCircularTareasActivas();
        while(!tareas_activas.esVacia()){
            Tarea t = tareas_activas.pop();
            if(t.getId_tarea().equals(id)) encontrada = t;
            auxA.push(t);
        }
        tareas_activas.vaciar(auxA);

        return encontrada;
    }

    private void registrarActualizacion(Tarea t, Empleado e, String desc) {
        Actualizacion act = new Actualizacion(
                this.pActualizacion.nroElem() + 1, desc, e, "18/11/25", "10:00", t
        );
        this.pActualizacion.adi(act);
    }
}