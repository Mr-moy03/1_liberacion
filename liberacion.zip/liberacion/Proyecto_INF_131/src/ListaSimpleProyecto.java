
public class ListaSimpleProyecto {
	protected NodoProyecto P;

	public ListaSimpleProyecto() {
		P = null;
	}

	public NodoProyecto getP() {
		return P;
	}

	public void setP(NodoProyecto p) {
		P = p;
	}
	
}
