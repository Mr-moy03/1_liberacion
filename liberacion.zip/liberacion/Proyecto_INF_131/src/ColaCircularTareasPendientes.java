public class ColaCircularTareasPendientes{
    protected int MAX = 50;
    protected Tarea[] v = new Tarea[MAX];
    protected int fr;
    protected int fi;
    public ColaCircularTareasPendientes() {
        this.fr = 0;
        this.fi = 0;
    }
    public int nroElem() {
        return (fi - fr + MAX) % MAX;
    }
    public boolean esVacia() {
        if(nroElem() == 0)
            return true;
        return false;

    }
    public boolean esLlena() {
        if(nroElem() == MAX-1)
            return true;
        return false;
    }
    public void push(Tarea elem) {
        if(!esLlena()) {
            fi = (fi + 1) % MAX;
            v[fi] = elem;
        }else
            System.out.println("cola circular llena!!!");
    }
    public Tarea pop() {
        Tarea elem;
        if(!esVacia()) {
            fr = (fr + 1) % MAX;
            elem = v[fr];
            return elem;
        }else {
            System.out.println("Cola circular vacia!!");
            return null;
        }
    }

    public void vaciar(ColaCircularTareasPendientes z) {
        while(!z.esVacia()) {
            push(z.pop());
        }
    }

    public void mostrar() {
        ColaCircularTareasPendientes aux = new ColaCircularTareasPendientes();
        while(!esVacia()) {
            Tarea elem = pop();
            elem.mostrar();
            aux.push(elem);
        }
        vaciar(aux);
    }
}
