package SesionColaCircularEstudiantes;

public class Main {
    public static void main(String[] args){
        //Objetos
        //libros
        Libro l1 = new Libro("Hacking",20);
        Libro l2 = new Libro("Java I",120);
        Libro l3 = new Libro("Python ",100);
        Libro l4 = new Libro("Ciencia de datos",200);
        Libro l5 = new Libro("C# tools",30);
        Libro l6 = new Libro("Kotlin para principiantes",35);
        //Pilas
        PilaLibro pl1 = new PilaLibro();
        PilaLibro pl2 = new PilaLibro();
        PilaLibro pl3 = new PilaLibro();
        PilaLibro pl4 = new PilaLibro();
        //->adiccion
        pl1.push(l1);
        pl1.push(l4);
        pl1.push(l2);

        pl2.push(l6);
        pl2.push(l2);
        pl2.push(l2);

        pl3.push(l5);
        pl3.push(l3);
        pl3.push(l1);

        pl4.push(l4);
        pl4.push(l2);
        pl4.push(l5);

        //estudiantes
        Estudiante est1 = new Estudiante("Juan",pl1);
        Estudiante est2 = new Estudiante("Maria",pl2);
        Estudiante est3 = new Estudiante("Ariel",pl3);
        Estudiante est4 = new Estudiante("Ilse",pl4);


        //Cola
        ColaCircularEst cc1 = new ColaCircularEst();
        cc1.push(est1);
        cc1.push(est2);
        cc1.push(est3);
        cc1.push(est4);
        cc1.mostrar();
        //Ejercicios
        System.out.println("__A)__");
        mostrarLibroEstduiante(cc1, l3);
        System.out.println("__B)__");
        mostrarLibrosDeYEstudiante(cc1, est3);
        System.out.println("__C)__");
        ordenarLibros(cc1);
        cc1.mostrar();
        System.out.println("__D)__");
        librosEnComun(cc1);







    }

    public static void mostrarLibroEstduiante(ColaCircularEst c, Libro lib) {
        int ne = c.nroElem();
        for (int i = 1; i <= ne; i++) {
            Estudiante x = c.pop();
            if(buscarLibro(x,lib))
                System.out.println("nombre estudiante: " +x.getNom());
            c.push(x);
        }
    }
    public static void mostrarLibrosDeYEstudiante(ColaCircularEst c, Estudiante est) {
        ColaCircularEst aux = new ColaCircularEst();
        Estudiante elem;
        while (!c.esVacia()){
            elem = c.pop();
            if (elem.equals(est)){
                elem.mostrar();
            }
            aux.push(elem);
        }
        c.vaciar(aux);


    }
    public static boolean buscarLibro(Estudiante e, Libro lib) {
        PilaLibro aux = new PilaLibro();
        boolean sw = false;
        while(!e.getPl().esVacia()) {
            Libro x = e.getPl().pop();
            if(x.getTitulo().equals(lib.getTitulo()) &&
                    x.getNroPag() == lib.getNroPag())
                sw = true;
            aux.push(x);
        }
        e.getPl().vaciar(aux);
        return sw;
    }
    public static void ordenarLibros(ColaCircularEst c) {
        ColaCircularEst aux = new ColaCircularEst();

        while (!c.esVacia()) {
            Estudiante estudiante = c.pop();
            PilaLibro pilaOrdenada = ordenarPilaLibrosPorTitulo(estudiante.getPl());
            estudiante.setPl(pilaOrdenada);
            aux.push(estudiante);
        }

        c.vaciar(aux);
    }
    private static PilaLibro ordenarPilaLibrosPorTitulo(PilaLibro pilaOriginal) {
        PilaLibro pilaAux = new PilaLibro();
        PilaLibro pilaOrdenada = new PilaLibro();

        while (!pilaOriginal.esVacia()) {
            Libro libroActual = pilaOriginal.pop();

            while (!pilaOrdenada.esVacia() &&
                    pilaOrdenada.v[pilaOrdenada.getTope()].getTitulo().compareToIgnoreCase(libroActual.getTitulo()) > 0) {
                pilaAux.push(pilaOrdenada.pop());
            }

            pilaOrdenada.push(libroActual);

            while (!pilaAux.esVacia()) {
                pilaOrdenada.push(pilaAux.pop());
            }
        }

        return pilaOrdenada;
    }
    public static void librosEnComun(ColaCircularEst c) {
        Estudiante primerEstudiante = obtenerPrimerEstudiante(c);
        Estudiante ultimoEstudiante = obtenerUltimoEstudiante(c);

        // Buscar libros en común
        System.out.println("Libros en común entre el PRIMER estudiante (" + primerEstudiante.getNom() +
                ") y el ÚLTIMO estudiante (" + ultimoEstudiante.getNom() + "):");

        PilaLibro comunes = encontrarLibrosComunes(primerEstudiante.getPl(), ultimoEstudiante.getPl());

        if (comunes.esVacia()) {
            System.out.println("No hay libros en común");
        } else {
            comunes.mostrar();
        }
    }
    private static Estudiante obtenerPrimerEstudiante(ColaCircularEst c) {
        if (c.esVacia())
            return null;

        int posicionPrimero = (c.fr + 1) % c.MAX;
        return c.v[posicionPrimero];
    }
    private static Estudiante obtenerUltimoEstudiante(ColaCircularEst c) {
        if (c.esVacia()) return null;
        return c.v[c.fi];
    }
    private static PilaLibro encontrarLibrosComunes(PilaLibro pila1, PilaLibro pila2) {
        PilaLibro comunes = new PilaLibro();
        PilaLibro copiaPila1 = copiarPila(pila1);
        PilaLibro copiaPila2 = copiarPila(pila2);

        while (!copiaPila1.esVacia()) {
            Libro libroActual = copiaPila1.pop();
            PilaLibro tempPila2 = copiarPila(copiaPila2);

            while (!tempPila2.esVacia()) {
                Libro libroComparar = tempPila2.pop();
                if (sonLibrosIguales(libroActual, libroComparar) && !existeEnPila(comunes, libroActual)) {
                    comunes.push(libroActual);
                    break;
                }
            }
        }
        return comunes;
    }
    private static PilaLibro copiarPila(PilaLibro original) {
        PilaLibro copia = new PilaLibro();
        PilaLibro aux = new PilaLibro();

        while (!original.esVacia()) {
            Libro libro = original.pop();
            aux.push(libro);
            copia.push(libro);
        }
        original.vaciar(aux);
        return copia;
    }
    private static boolean sonLibrosIguales(Libro l1, Libro l2) {
        return l1.getTitulo().equalsIgnoreCase(l2.getTitulo()) && l1.getNroPag() == l2.getNroPag();
    }
    private static boolean existeEnPila(PilaLibro pila, Libro libro) {
        PilaLibro aux = new PilaLibro();
        boolean existe = false;
        while (!pila.esVacia()) {
            Libro actual = pila.pop();
            if (sonLibrosIguales(actual, libro)) {
                existe = true;
            }
            aux.push(actual);
        }
        pila.vaciar(aux);
        return existe;
    }


}
